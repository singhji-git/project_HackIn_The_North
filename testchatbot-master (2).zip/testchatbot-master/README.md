#How to Provide Replies about Shipping Costs via Api.ai Webhook

This example shows how you can use Api.ai webhook to provide different shipping costs depending on the world region.

<a href="https://heroku.com/deploy" target="_blank"><img src="https://www.herokucdn.com/deploy/button.svg"></a>